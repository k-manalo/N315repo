function initButtons() {

   
   
    $(".get-started").click(function(e) {      
        $('#home div').removeClass('active');
        $('#addNav div').addClass(' active');
        $('.text-wrapper').html(TREEFROG_SERVICE.getGetStartedContent());
        $('.btn-holder').html(TREEFROG_SERVICE.getCreateNavButton());

        
        console.log("clicked");
        
    });

    $('#home').click(function() {
        $('#addNav div').removeClass('active');
        $('#home div').addClass(' active');

        $('.text-wrapper').html(TREEFROG_SERVICE.getHomeContent());
        $('.btn-holder').html(TREEFROG_SERVICE.getHomeStartButton());
    })

    $("main-nav").onclick = function() {
      console.log("clicked");
        $('.alert-box').html(TREEFROG_SERVICE.getCreateNavContent());
        $(".modal").css("display", "block");
        
        
    }

    

   

   
};

$(document).ready(function() {
   initButtons(); 
   

});